CREATE FUNCTION bit_length (bit) RETURNS integer
	LANGUAGE sql
AS $$
select pg_catalog.length($1)
$$
