CREATE FUNCTION overlaps (timestamp with time zone, interval, timestamp with time zone, timestamp with time zone) RETURNS boolean
	LANGUAGE sql
AS $$
select ($1, ($1 + $2)) overlaps ($3, $4)
$$
