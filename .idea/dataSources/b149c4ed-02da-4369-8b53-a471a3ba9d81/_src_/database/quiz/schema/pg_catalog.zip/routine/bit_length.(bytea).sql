CREATE FUNCTION bit_length (bytea) RETURNS integer
	LANGUAGE sql
AS $$
select pg_catalog.octet_length($1) * 8
$$
